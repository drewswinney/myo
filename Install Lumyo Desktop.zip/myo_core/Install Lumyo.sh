#! /bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd $DIR

pip install virtualenv
virtualenv env --no-site-packages
source env/bin/activate

pip install enum34 six requests

git clone https://github.com/NiklasRosenstein/myo-python.git
pip install -e myo-python

profile="$HOME/.bash_profile"
touch $profile
echo "export DYLD_LIBRARY_PATH=$DYLD_LIBRARY_PATH:$DIR/myo.framework" >> $profile
source $profile
export DYLD_LIBRARY_PATH=$DYLD_LIBRARY_PATH:$DIR/myo.framework

git clone https://github.com/drewswinney/myo.git

cd myo/Lumyo\ Desktop/Lumyo\ Python
python Lumyo.py

$SHELL
# enum34==1.0.4 six==1.4.1 requests==2.8.1