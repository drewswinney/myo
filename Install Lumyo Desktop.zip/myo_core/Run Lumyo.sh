#! /bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd $DIR
source env/bin/activate
export DYLD_LIBRARY_PATH=$DYLD_LIBRARY_PATH:$DIR/myo.framework
cd myo/Lumyo\ Desktop/Lumyo\ Python
python Lumyo.py
$SHELL